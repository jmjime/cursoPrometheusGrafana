package com.devs4j.users;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsersAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
