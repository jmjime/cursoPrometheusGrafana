/**
 * 
 */
package com.devs4j.core.scopes;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * @author maagapi
 *
 */
@Component
@Scope("prototype")
public class PrototypeBean {

}
