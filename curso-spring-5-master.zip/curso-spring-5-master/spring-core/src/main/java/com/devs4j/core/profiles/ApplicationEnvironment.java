/**
 * 
 */
package com.devs4j.core.profiles;

/**
 * @author maagapi
 *
 */
public interface ApplicationEnvironment {

	public String getEnvironment();
}
