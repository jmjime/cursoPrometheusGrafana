package com.devs4j.core.aop.proxies;

public interface Coche {

	public void avanzar();
}